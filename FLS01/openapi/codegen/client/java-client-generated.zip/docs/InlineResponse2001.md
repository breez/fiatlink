# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**UUID**](UUID.md) |  | 
**token** | **String** |  |  [optional]
**expiresOn** | [**OffsetDateTime**](OffsetDateTime.md) |  | 
