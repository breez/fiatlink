# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**UUID**](UUID.md) |  | 
**appId** | [**UUID**](UUID.md) |  |  [optional]
**expiresOn** | [**OffsetDateTime**](OffsetDateTime.md) |  | 
