# IO.Swagger.Model.OrderBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SessionId** | **Guid?** |  | 
**QuoteId** | **Guid?** |  | 
**WebhookUrl** | **string** | optional webhook for notifications | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

