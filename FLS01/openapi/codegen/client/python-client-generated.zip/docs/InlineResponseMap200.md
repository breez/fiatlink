# InlineResponseMap200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount_fiat** | **int** |  | [optional] 
**currency_id** | **int** |  | [optional] 
**payment_option_id** | **int** |  | [optional] 
**amount_sats** | **int** |  | [optional] 
**btc_price** | **int** |  | [optional] 
**order_fee** | **int** |  | [optional] 
**order_status** | **str** |  | [optional] 
**order_status_date** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

