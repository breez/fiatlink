# FiatlinkFls01.OrderstatusBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **String** |  | [optional] 
**orderId** | **String** |  | [optional] 
