# FiatlinkFls01.WithdrawalBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **String** |  | 
**orderId** | **String** |  | 
**failbackOnchain** | **String** |  | [optional] 
