# InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currencies** | [**kotlin.Array&lt;kotlin.collections.Map&lt;kotlin.String, kotlin.Any&gt;&gt;**](.md) |  |  [optional]
