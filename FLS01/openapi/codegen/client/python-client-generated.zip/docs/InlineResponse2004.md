# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**order_id** | **str** |  | [optional] 
**order_status** | **str** |  | [optional] 
**amount_fiat** | **int** |  | [optional] 
**currency_id** | **int** |  | [optional] 
**payment_option_id** | **int** |  | [optional] 
**amount_sats** | **int** |  | [optional] 
**expires_on** | **datetime** | by when the payment needs to arrive for the order to be honored | [optional] 
**payment_info** | **dict(str, object)** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

