# OrderstatusBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**java.util.UUID**](java.util.UUID.md) |  |  [optional]
**orderId** | [**java.util.UUID**](java.util.UUID.md) |  |  [optional]
