# IO.Swagger.Model.InlineResponseMap200
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AmountFiat** | **int?** |  | [optional] 
**CurrencyId** | **int?** |  | [optional] 
**PaymentOptionId** | **int?** |  | [optional] 
**AmountSats** | **int?** |  | [optional] 
**BtcPrice** | **int?** |  | [optional] 
**OrderFee** | **int?** |  | [optional] 
**OrderStatus** | **string** |  | [optional] 
**OrderStatusDate** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

