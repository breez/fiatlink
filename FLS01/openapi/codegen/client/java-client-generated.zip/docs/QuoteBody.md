# QuoteBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
