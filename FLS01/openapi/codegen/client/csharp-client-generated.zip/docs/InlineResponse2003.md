# IO.Swagger.Model.InlineResponse2003
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**QuoteId** | **Guid?** |  | [optional] 
**AmountFiat** | **int?** |  | 
**CurrencyId** | **int?** |  | 
**PaymentOptionId** | **int?** |  | 
**AmountSats** | **int?** |  | 
**IsEstimate** | **bool?** | return true if estimate or false if quote | [default to true]
**BtcPrice** | **int?** |  | 
**OrderFee** | **int?** |  | 
**ExpiresOn** | **DateTime?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

