# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supportedFeatures** | [**kotlin.Array&lt;kotlin.Any&gt;**](.md) |  |  [optional]
