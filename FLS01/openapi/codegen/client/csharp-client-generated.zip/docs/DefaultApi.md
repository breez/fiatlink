# IO.Swagger.Api.DefaultApi

All URIs are relative to *https://virtserver.swaggerhub.com/ALJAZ/fiatlink/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**FeaturesGet**](DefaultApi.md#featuresget) | **GET** /features | Get supported features
[**OrderPost**](DefaultApi.md#orderpost) | **POST** /order | Create an order
[**OrderStatusPost**](DefaultApi.md#orderstatuspost) | **POST** /order-status | Get order status
[**PaymentOptionsPost**](DefaultApi.md#paymentoptionspost) | **POST** /payment-options | Get payment options
[**QuotePost**](DefaultApi.md#quotepost) | **POST** /quote | Get a quote or estimate
[**SessionPost**](DefaultApi.md#sessionpost) | **POST** /session | Start a session
[**VerifyGet**](DefaultApi.md#verifyget) | **GET** /verify | Provides token for authentication
[**WithdrawalPost**](DefaultApi.md#withdrawalpost) | **POST** /withdrawal | Initiate a withdrawal

<a name="featuresget"></a>
# **FeaturesGet**
> InlineResponse200 FeaturesGet ()

Get supported features

Endpoint to retrieve supported features

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class FeaturesGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();

            try
            {
                // Get supported features
                InlineResponse200 result = apiInstance.FeaturesGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.FeaturesGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="orderpost"></a>
# **OrderPost**
> InlineResponse2004 OrderPost (OrderBody body)

Create an order

Confirm an order from quote and get payment information in return

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderPostExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var body = new OrderBody(); // OrderBody | 

            try
            {
                // Create an order
                InlineResponse2004 result = apiInstance.OrderPost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.OrderPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrderBody**](OrderBody.md)|  | 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="orderstatuspost"></a>
# **OrderStatusPost**
> Dictionary<string, InlineResponseMap200> OrderStatusPost (OrderstatusBody body)

Get order status

This endpoint returns the status of one or more orders based on the session and order ID.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class OrderStatusPostExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var body = new OrderstatusBody(); // OrderstatusBody | 

            try
            {
                // Get order status
                Dictionary&lt;string, InlineResponseMap200&gt; result = apiInstance.OrderStatusPost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.OrderStatusPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrderstatusBody**](OrderstatusBody.md)|  | 

### Return type

[**Dictionary<string, InlineResponseMap200>**](InlineResponseMap200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="paymentoptionspost"></a>
# **PaymentOptionsPost**
> InlineResponse2006 PaymentOptionsPost (PaymentoptionsBody body)

Get payment options

This endpoint provides a list of payment options for different currencies, filtered by an optional currency code.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class PaymentOptionsPostExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var body = new PaymentoptionsBody(); // PaymentoptionsBody | 

            try
            {
                // Get payment options
                InlineResponse2006 result = apiInstance.PaymentOptionsPost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.PaymentOptionsPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PaymentoptionsBody**](PaymentoptionsBody.md)|  | 

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="quotepost"></a>
# **QuotePost**
> InlineResponse2003 QuotePost (QuoteBody body)

Get a quote or estimate

Get a an quote or estimate from the provider based on amount of fiat you want to spend

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class QuotePostExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var body = new QuoteBody(); // QuoteBody | 

            try
            {
                // Get a quote or estimate
                InlineResponse2003 result = apiInstance.QuotePost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.QuotePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**QuoteBody**](QuoteBody.md)|  | 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="sessionpost"></a>
# **SessionPost**
> InlineResponse2002 SessionPost (SessionBody body)

Start a session

Start a session with optional signed proof of ownership. If Proof of Ownership is not required signature can be a random alphanumeric value.

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class SessionPostExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var body = new SessionBody(); // SessionBody | 

            try
            {
                // Start a session
                InlineResponse2002 result = apiInstance.SessionPost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.SessionPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SessionBody**](SessionBody.md)|  | 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="verifyget"></a>
# **VerifyGet**
> InlineResponse2001 VerifyGet ()

Provides token for authentication

Request a token to be signed by the reciever node as proof of ownership

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class VerifyGetExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();

            try
            {
                // Provides token for authentication
                InlineResponse2001 result = apiInstance.VerifyGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.VerifyGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="withdrawalpost"></a>
# **WithdrawalPost**
> InlineResponse2005 WithdrawalPost (WithdrawalBody body)

Initiate a withdrawal

Request lnurlw from the provider. User can provide optional fallback onchain address which will be used if the withdrawal is not claimed before the expiration date

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class WithdrawalPostExample
    {
        public void main()
        {
            var apiInstance = new DefaultApi();
            var body = new WithdrawalBody(); // WithdrawalBody | 

            try
            {
                // Initiate a withdrawal
                InlineResponse2005 result = apiInstance.WithdrawalPost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling DefaultApi.WithdrawalPost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**WithdrawalBody**](WithdrawalBody.md)|  | 

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
