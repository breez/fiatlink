# SessionBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**UUID**](UUID.md) |  | 
**appId** | [**UUID**](UUID.md) | serves as identifier of the application |  [optional]
**signature** | **String** | token signed with the node&#x27;s private key, in zbase32 format | 
**nodePubkey** | **String** |  |  [optional]
