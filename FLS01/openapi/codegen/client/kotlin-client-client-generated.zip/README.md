# io.swagger.client - Kotlin client library for Fiatlink FLS01

## Requires

* Kotlin 1.4.30
* Gradle 5.3

## Build

First, create the gradle wrapper script:

```
gradle wrapper
```

Then, run:

```
./gradlew check assemble
```

This runs all tests and packages the library.

## Features/Implementation Notes

* Supports JSON inputs/outputs, File inputs, and Form inputs.
* Supports collection formats for query parameters: csv, tsv, ssv, pipes.
* Some Kotlin and Java types are fully qualified to avoid conflicts with types defined in Swagger definitions.
* Implementation of ApiClient is intended to reduce method counts, specifically to benefit Android targets.

<a name="documentation-for-api-endpoints"></a>
## Documentation for API Endpoints

All URIs are relative to *https://virtserver.swaggerhub.com/ALJAZ/fiatlink/1.0.0*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*DefaultApi* | [**featuresGet**](docs/DefaultApi.md#featuresget) | **GET** /features | Get supported features
*DefaultApi* | [**orderPost**](docs/DefaultApi.md#orderpost) | **POST** /order | Create an order
*DefaultApi* | [**orderStatusPost**](docs/DefaultApi.md#orderstatuspost) | **POST** /order-status | Get order status
*DefaultApi* | [**paymentOptionsPost**](docs/DefaultApi.md#paymentoptionspost) | **POST** /payment-options | Get payment options
*DefaultApi* | [**quotePost**](docs/DefaultApi.md#quotepost) | **POST** /quote | Get a quote or estimate
*DefaultApi* | [**sessionPost**](docs/DefaultApi.md#sessionpost) | **POST** /session | Start a session
*DefaultApi* | [**verifyGet**](docs/DefaultApi.md#verifyget) | **GET** /verify | Provides token for authentication
*DefaultApi* | [**withdrawalPost**](docs/DefaultApi.md#withdrawalpost) | **POST** /withdrawal | Initiate a withdrawal

<a name="documentation-for-models"></a>
## Documentation for Models

 - [io.swagger.client.models.InlineResponse200](docs/InlineResponse200.md)
 - [io.swagger.client.models.InlineResponse2001](docs/InlineResponse2001.md)
 - [io.swagger.client.models.InlineResponse2002](docs/InlineResponse2002.md)
 - [io.swagger.client.models.InlineResponse2003](docs/InlineResponse2003.md)
 - [io.swagger.client.models.InlineResponse2004](docs/InlineResponse2004.md)
 - [io.swagger.client.models.InlineResponse2005](docs/InlineResponse2005.md)
 - [io.swagger.client.models.InlineResponse2006](docs/InlineResponse2006.md)
 - [io.swagger.client.models.InlineResponseMap200](docs/InlineResponseMap200.md)
 - [io.swagger.client.models.OrderBody](docs/OrderBody.md)
 - [io.swagger.client.models.OrderstatusBody](docs/OrderstatusBody.md)
 - [io.swagger.client.models.PaymentoptionsBody](docs/PaymentoptionsBody.md)
 - [io.swagger.client.models.QuoteBody](docs/QuoteBody.md)
 - [io.swagger.client.models.SessionBody](docs/SessionBody.md)
 - [io.swagger.client.models.WithdrawalBody](docs/WithdrawalBody.md)

<a name="documentation-for-authorization"></a>
## Documentation for Authorization

All endpoints do not require authorization.
