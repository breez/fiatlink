# FiatlinkFls01.InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currencies** | **[{String: Object}]** |  | [optional] 
