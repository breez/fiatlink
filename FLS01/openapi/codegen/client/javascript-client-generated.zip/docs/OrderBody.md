# FiatlinkFls01.OrderBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **String** |  | 
**quoteId** | **String** |  | 
**webhookUrl** | **String** | optional webhook for notifications | [optional] 
