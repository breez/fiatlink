# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OrderId** | **string** |  | [optional] [default to null]
**OrderStatus** | **string** |  | [optional] [default to null]
**AmountFiat** | **int32** |  | [optional] [default to null]
**CurrencyId** | **int32** |  | [optional] [default to null]
**PaymentOptionId** | **int32** |  | [optional] [default to null]
**AmountSats** | **int32** |  | [optional] [default to null]
**ExpiresOn** | [**time.Time**](time.Time.md) | by when the payment needs to arrive for the order to be honored | [optional] [default to null]
**PaymentInfo** | [**ModelMap**](interface{}.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

