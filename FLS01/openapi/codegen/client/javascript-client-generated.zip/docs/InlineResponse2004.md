# FiatlinkFls01.InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | **String** |  | [optional] 
**orderStatus** | **String** |  | [optional] 
**amountFiat** | **Number** |  | [optional] 
**currencyId** | **Number** |  | [optional] 
**paymentOptionId** | **Number** |  | [optional] 
**amountSats** | **Number** |  | [optional] 
**expiresOn** | **Date** | by when the payment needs to arrive for the order to be honored | [optional] 
**paymentInfo** | **{String: Object}** |  | [optional] 
