# SessionBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**session_id** | **str** |  | 
**app_id** | **str** | serves as identifier of the application | [optional] 
**signature** | **str** | token signed with the node&#x27;s private key, in zbase32 format | 
**node_pubkey** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

