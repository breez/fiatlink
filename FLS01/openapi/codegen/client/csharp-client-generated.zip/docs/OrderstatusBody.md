# IO.Swagger.Model.OrderstatusBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SessionId** | **Guid?** |  | [optional] 
**OrderId** | **Guid?** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

