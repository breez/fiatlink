# InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**java.util.UUID**](java.util.UUID.md) |  | 
**token** | [**kotlin.String**](.md) |  |  [optional]
**expiresOn** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) |  | 
