# FiatlinkFls01.InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **String** |  | 
**token** | **String** |  | [optional] 
**expiresOn** | **Date** |  | 
