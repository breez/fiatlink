# InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**java.util.UUID**](java.util.UUID.md) |  | 
**appId** | [**java.util.UUID**](java.util.UUID.md) |  |  [optional]
**expiresOn** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) |  | 
