# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | [**java.util.UUID**](java.util.UUID.md) |  |  [optional]
**orderStatus** | [**kotlin.String**](.md) |  |  [optional]
**amountFiat** | [**kotlin.Int**](.md) |  |  [optional]
**currencyId** | [**kotlin.Int**](.md) |  |  [optional]
**paymentOptionId** | [**kotlin.Int**](.md) |  |  [optional]
**amountSats** | [**kotlin.Int**](.md) |  |  [optional]
**expiresOn** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | by when the payment needs to arrive for the order to be honored |  [optional]
**paymentInfo** | [**kotlin.collections.Map&lt;kotlin.String, kotlin.Any&gt;**](.md) |  |  [optional]
