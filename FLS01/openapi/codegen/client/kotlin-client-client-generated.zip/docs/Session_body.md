# SessionBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**java.util.UUID**](java.util.UUID.md) |  | 
**appId** | [**java.util.UUID**](java.util.UUID.md) | serves as identifier of the application |  [optional]
**signature** | [**kotlin.String**](.md) | token signed with the node&#x27;s private key, in zbase32 format | 
**nodePubkey** | [**kotlin.String**](.md) |  |  [optional]
