# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supportedFeatures** | **List&lt;Object&gt;** |  |  [optional]
