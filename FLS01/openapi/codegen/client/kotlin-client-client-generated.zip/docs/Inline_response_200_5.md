# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | [**java.util.UUID**](java.util.UUID.md) |  |  [optional]
**withdrawalExpirationDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) |  |  [optional]
**lnurlw** | [**kotlin.String**](.md) |  |  [optional]
