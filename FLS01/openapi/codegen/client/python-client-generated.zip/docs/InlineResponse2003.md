# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quote_id** | **str** |  | [optional] 
**amount_fiat** | **int** |  | 
**currency_id** | **int** |  | 
**payment_option_id** | **int** |  | 
**amount_sats** | **int** |  | 
**is_estimate** | **bool** | return true if estimate or false if quote | [default to True]
**btc_price** | **int** |  | 
**order_fee** | **int** |  | 
**expires_on** | **datetime** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

