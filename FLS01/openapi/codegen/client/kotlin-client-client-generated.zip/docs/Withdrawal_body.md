# WithdrawalBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**java.util.UUID**](java.util.UUID.md) |  | 
**orderId** | [**java.util.UUID**](java.util.UUID.md) |  | 
**failbackOnchain** | [**kotlin.String**](.md) |  |  [optional]
