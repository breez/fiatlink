'use strict';

var utils = require('../utils/writer.js');
var Default = require('../service/DefaultService');

module.exports.featuresGET = function featuresGET (req, res, next) {
  Default.featuresGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.orderPOST = function orderPOST (req, res, next, body) {
  Default.orderPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.order_statusPOST = function order_statusPOST (req, res, next, body) {
  Default.order_statusPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.payment_optionsPOST = function payment_optionsPOST (req, res, next, body) {
  Default.payment_optionsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.quotePOST = function quotePOST (req, res, next, body) {
  Default.quotePOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.sessionPOST = function sessionPOST (req, res, next, body) {
  Default.sessionPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.verifyGET = function verifyGET (req, res, next) {
  Default.verifyGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.withdrawalPOST = function withdrawalPOST (req, res, next, body) {
  Default.withdrawalPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
