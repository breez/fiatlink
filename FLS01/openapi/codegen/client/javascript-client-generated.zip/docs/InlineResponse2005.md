# FiatlinkFls01.InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | **String** |  | [optional] 
**withdrawalExpirationDate** | **Date** |  | [optional] 
**lnurlw** | **String** |  | [optional] 
