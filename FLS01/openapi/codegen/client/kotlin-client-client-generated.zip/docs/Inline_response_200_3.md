# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quoteId** | [**java.util.UUID**](java.util.UUID.md) |  |  [optional]
**amountFiat** | [**kotlin.Int**](.md) |  | 
**currencyId** | [**kotlin.Int**](.md) |  | 
**paymentOptionId** | [**kotlin.Int**](.md) |  | 
**amountSats** | [**kotlin.Int**](.md) |  | 
**isEstimate** | [**kotlin.Boolean**](.md) | return true if estimate or false if quote | 
**btcPrice** | [**kotlin.Int**](.md) |  | 
**orderFee** | [**kotlin.Int**](.md) |  | 
**expiresOn** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) |  |  [optional]
