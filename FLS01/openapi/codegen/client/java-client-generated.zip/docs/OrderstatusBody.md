# OrderstatusBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**UUID**](UUID.md) |  |  [optional]
**orderId** | [**UUID**](UUID.md) |  |  [optional]
