# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | [**UUID**](UUID.md) |  |  [optional]
**withdrawalExpirationDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
**lnurlw** | **String** |  |  [optional]
