# FiatlinkFls01.InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **String** |  | 
**appId** | **String** |  | [optional] 
**expiresOn** | **Date** |  | 
