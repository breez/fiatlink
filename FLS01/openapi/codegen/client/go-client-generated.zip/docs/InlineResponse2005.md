# InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OrderId** | **string** |  | [optional] [default to null]
**WithdrawalExpirationDate** | [**time.Time**](time.Time.md) |  | [optional] [default to null]
**Lnurlw** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

