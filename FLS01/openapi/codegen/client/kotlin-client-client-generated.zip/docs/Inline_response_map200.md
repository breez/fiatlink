# InlineResponseMap200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountFiat** | [**kotlin.Int**](.md) |  |  [optional]
**currencyId** | [**kotlin.Int**](.md) |  |  [optional]
**paymentOptionId** | [**kotlin.Int**](.md) |  |  [optional]
**amountSats** | [**kotlin.Int**](.md) |  |  [optional]
**btcPrice** | [**kotlin.Int**](.md) |  |  [optional]
**orderFee** | [**kotlin.Int**](.md) |  |  [optional]
**orderStatus** | [**kotlin.String**](.md) |  |  [optional]
**orderStatusDate** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) |  |  [optional]
