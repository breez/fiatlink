# IO.Swagger.Model.InlineResponse2004
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**OrderId** | **Guid?** |  | [optional] 
**OrderStatus** | **string** |  | [optional] 
**AmountFiat** | **int?** |  | [optional] 
**CurrencyId** | **int?** |  | [optional] 
**PaymentOptionId** | **int?** |  | [optional] 
**AmountSats** | **int?** |  | [optional] 
**ExpiresOn** | **DateTime?** | by when the payment needs to arrive for the order to be honored | [optional] 
**PaymentInfo** | **Dictionary&lt;string, Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

