# FiatlinkFls01.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**supportedFeatures** | **[Object]** |  | [optional] 
