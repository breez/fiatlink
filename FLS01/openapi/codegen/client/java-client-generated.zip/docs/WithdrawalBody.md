# WithdrawalBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**UUID**](UUID.md) |  | 
**orderId** | [**UUID**](UUID.md) |  | 
**failbackOnchain** | **String** |  |  [optional]
