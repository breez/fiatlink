# DefaultApi

All URIs are relative to *https://virtserver.swaggerhub.com/ALJAZ/fiatlink/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**featuresGet**](DefaultApi.md#featuresGet) | **GET** /features | Get supported features
[**orderPost**](DefaultApi.md#orderPost) | **POST** /order | Create an order
[**orderStatusPost**](DefaultApi.md#orderStatusPost) | **POST** /order-status | Get order status
[**paymentOptionsPost**](DefaultApi.md#paymentOptionsPost) | **POST** /payment-options | Get payment options
[**quotePost**](DefaultApi.md#quotePost) | **POST** /quote | Get a quote or estimate
[**sessionPost**](DefaultApi.md#sessionPost) | **POST** /session | Start a session
[**verifyGet**](DefaultApi.md#verifyGet) | **GET** /verify | Provides token for authentication
[**withdrawalPost**](DefaultApi.md#withdrawalPost) | **POST** /withdrawal | Initiate a withdrawal

<a name="featuresGet"></a>
# **featuresGet**
> InlineResponse200 featuresGet()

Get supported features

Endpoint to retrieve supported features

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = DefaultApi()
try {
    val result : InlineResponse200 = apiInstance.featuresGet()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#featuresGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#featuresGet")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="orderPost"></a>
# **orderPost**
> InlineResponse2004 orderPost(body)

Create an order

Confirm an order from quote and get payment information in return

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = DefaultApi()
val body : OrderBody =  // OrderBody | 
try {
    val result : InlineResponse2004 = apiInstance.orderPost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#orderPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#orderPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrderBody**](OrderBody.md)|  |

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderStatusPost"></a>
# **orderStatusPost**
> kotlin.collections.Map&lt;kotlin.String, InlineResponseMap200&gt; orderStatusPost(body)

Get order status

This endpoint returns the status of one or more orders based on the session and order ID.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = DefaultApi()
val body : OrderstatusBody =  // OrderstatusBody | 
try {
    val result : kotlin.collections.Map<kotlin.String, InlineResponseMap200> = apiInstance.orderStatusPost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#orderStatusPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#orderStatusPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrderstatusBody**](OrderstatusBody.md)|  |

### Return type

[**kotlin.collections.Map&lt;kotlin.String, InlineResponseMap200&gt;**](InlineResponseMap200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentOptionsPost"></a>
# **paymentOptionsPost**
> InlineResponse2006 paymentOptionsPost(body)

Get payment options

This endpoint provides a list of payment options for different currencies, filtered by an optional currency code.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = DefaultApi()
val body : PaymentoptionsBody =  // PaymentoptionsBody | 
try {
    val result : InlineResponse2006 = apiInstance.paymentOptionsPost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#paymentOptionsPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#paymentOptionsPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PaymentoptionsBody**](PaymentoptionsBody.md)|  |

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quotePost"></a>
# **quotePost**
> InlineResponse2003 quotePost(body)

Get a quote or estimate

Get a an quote or estimate from the provider based on amount of fiat you want to spend

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = DefaultApi()
val body : QuoteBody =  // QuoteBody | 
try {
    val result : InlineResponse2003 = apiInstance.quotePost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#quotePost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#quotePost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**QuoteBody**](QuoteBody.md)|  |

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sessionPost"></a>
# **sessionPost**
> InlineResponse2002 sessionPost(body)

Start a session

Start a session with optional signed proof of ownership. If Proof of Ownership is not required signature can be a random alphanumeric value.

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = DefaultApi()
val body : SessionBody =  // SessionBody | 
try {
    val result : InlineResponse2002 = apiInstance.sessionPost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#sessionPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#sessionPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SessionBody**](SessionBody.md)|  |

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="verifyGet"></a>
# **verifyGet**
> InlineResponse2001 verifyGet()

Provides token for authentication

Request a token to be signed by the reciever node as proof of ownership

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = DefaultApi()
try {
    val result : InlineResponse2001 = apiInstance.verifyGet()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#verifyGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#verifyGet")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="withdrawalPost"></a>
# **withdrawalPost**
> InlineResponse2005 withdrawalPost(body)

Initiate a withdrawal

Request lnurlw from the provider. User can provide optional fallback onchain address which will be used if the withdrawal is not claimed before the expiration date

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = DefaultApi()
val body : WithdrawalBody =  // WithdrawalBody | 
try {
    val result : InlineResponse2005 = apiInstance.withdrawalPost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#withdrawalPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#withdrawalPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**WithdrawalBody**](WithdrawalBody.md)|  |

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

