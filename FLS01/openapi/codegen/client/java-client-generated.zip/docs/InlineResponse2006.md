# InlineResponse2006

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currencies** | [**List&lt;Map&lt;String, Object&gt;&gt;**](Map.md) |  |  [optional]
