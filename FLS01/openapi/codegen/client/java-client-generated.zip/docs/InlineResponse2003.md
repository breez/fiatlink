# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quoteId** | [**UUID**](UUID.md) |  |  [optional]
**amountFiat** | **Integer** |  | 
**currencyId** | **Integer** |  | 
**paymentOptionId** | **Integer** |  | 
**amountSats** | **Integer** |  | 
**isEstimate** | **Boolean** | return true if estimate or false if quote | 
**btcPrice** | **Integer** |  | 
**orderFee** | **Integer** |  | 
**expiresOn** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
