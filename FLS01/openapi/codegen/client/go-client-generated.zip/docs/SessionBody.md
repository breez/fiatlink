# SessionBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SessionId** | **string** |  | [default to null]
**AppId** | **string** | serves as identifier of the application | [optional] [default to null]
**Signature** | **string** | token signed with the node&#x27;s private key, in zbase32 format | [default to null]
**NodePubkey** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

