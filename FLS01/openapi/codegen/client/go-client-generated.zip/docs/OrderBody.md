# OrderBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SessionId** | **string** |  | [default to null]
**QuoteId** | **string** |  | [default to null]
**WebhookUrl** | **string** | optional webhook for notifications | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

