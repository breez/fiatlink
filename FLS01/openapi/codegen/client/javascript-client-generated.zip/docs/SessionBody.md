# FiatlinkFls01.SessionBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **String** |  | 
**appId** | **String** | serves as identifier of the application | [optional] 
**signature** | **String** | token signed with the node&#x27;s private key, in zbase32 format | 
**nodePubkey** | **String** |  | [optional] 
