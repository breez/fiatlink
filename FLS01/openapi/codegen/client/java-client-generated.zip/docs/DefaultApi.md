# DefaultApi

All URIs are relative to *https://virtserver.swaggerhub.com/ALJAZ/fiatlink/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**featuresGet**](DefaultApi.md#featuresGet) | **GET** /features | Get supported features
[**orderPost**](DefaultApi.md#orderPost) | **POST** /order | Create an order
[**orderStatusPost**](DefaultApi.md#orderStatusPost) | **POST** /order-status | Get order status
[**paymentOptionsPost**](DefaultApi.md#paymentOptionsPost) | **POST** /payment-options | Get payment options
[**quotePost**](DefaultApi.md#quotePost) | **POST** /quote | Get a quote or estimate
[**sessionPost**](DefaultApi.md#sessionPost) | **POST** /session | Start a session
[**verifyGet**](DefaultApi.md#verifyGet) | **GET** /verify | Provides token for authentication
[**withdrawalPost**](DefaultApi.md#withdrawalPost) | **POST** /withdrawal | Initiate a withdrawal

<a name="featuresGet"></a>
# **featuresGet**
> InlineResponse200 featuresGet()

Get supported features

Endpoint to retrieve supported features

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    InlineResponse200 result = apiInstance.featuresGet();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#featuresGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="orderPost"></a>
# **orderPost**
> InlineResponse2004 orderPost(body)

Create an order

Confirm an order from quote and get payment information in return

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
OrderBody body = new OrderBody(); // OrderBody | 
try {
    InlineResponse2004 result = apiInstance.orderPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#orderPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrderBody**](OrderBody.md)|  |

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="orderStatusPost"></a>
# **orderStatusPost**
> Map&lt;String, InlineResponseMap200&gt; orderStatusPost(body)

Get order status

This endpoint returns the status of one or more orders based on the session and order ID.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
OrderstatusBody body = new OrderstatusBody(); // OrderstatusBody | 
try {
    Map<String, InlineResponseMap200> result = apiInstance.orderStatusPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#orderStatusPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrderstatusBody**](OrderstatusBody.md)|  |

### Return type

[**Map&lt;String, InlineResponseMap200&gt;**](InlineResponseMap200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="paymentOptionsPost"></a>
# **paymentOptionsPost**
> InlineResponse2006 paymentOptionsPost(body)

Get payment options

This endpoint provides a list of payment options for different currencies, filtered by an optional currency code.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
PaymentoptionsBody body = new PaymentoptionsBody(); // PaymentoptionsBody | 
try {
    InlineResponse2006 result = apiInstance.paymentOptionsPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#paymentOptionsPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PaymentoptionsBody**](PaymentoptionsBody.md)|  |

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quotePost"></a>
# **quotePost**
> InlineResponse2003 quotePost(body)

Get a quote or estimate

Get a an quote or estimate from the provider based on amount of fiat you want to spend

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
QuoteBody body = new QuoteBody(); // QuoteBody | 
try {
    InlineResponse2003 result = apiInstance.quotePost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#quotePost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**QuoteBody**](QuoteBody.md)|  |

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="sessionPost"></a>
# **sessionPost**
> InlineResponse2002 sessionPost(body)

Start a session

Start a session with optional signed proof of ownership. If Proof of Ownership is not required signature can be a random alphanumeric value.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
SessionBody body = new SessionBody(); // SessionBody | 
try {
    InlineResponse2002 result = apiInstance.sessionPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#sessionPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SessionBody**](SessionBody.md)|  |

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="verifyGet"></a>
# **verifyGet**
> InlineResponse2001 verifyGet()

Provides token for authentication

Request a token to be signed by the reciever node as proof of ownership

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
try {
    InlineResponse2001 result = apiInstance.verifyGet();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#verifyGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="withdrawalPost"></a>
# **withdrawalPost**
> InlineResponse2005 withdrawalPost(body)

Initiate a withdrawal

Request lnurlw from the provider. User can provide optional fallback onchain address which will be used if the withdrawal is not claimed before the expiration date

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
WithdrawalBody body = new WithdrawalBody(); // WithdrawalBody | 
try {
    InlineResponse2005 result = apiInstance.withdrawalPost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#withdrawalPost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**WithdrawalBody**](WithdrawalBody.md)|  |

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

