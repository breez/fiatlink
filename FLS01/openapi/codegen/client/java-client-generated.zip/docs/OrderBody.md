# OrderBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**UUID**](UUID.md) |  | 
**quoteId** | [**UUID**](UUID.md) |  | 
**webhookUrl** | **String** | optional webhook for notifications |  [optional]
