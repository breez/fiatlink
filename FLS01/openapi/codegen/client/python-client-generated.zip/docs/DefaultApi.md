# swagger_client.DefaultApi

All URIs are relative to *https://virtserver.swaggerhub.com/ALJAZ/fiatlink/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**features_get**](DefaultApi.md#features_get) | **GET** /features | Get supported features
[**order_post**](DefaultApi.md#order_post) | **POST** /order | Create an order
[**order_status_post**](DefaultApi.md#order_status_post) | **POST** /order-status | Get order status
[**payment_options_post**](DefaultApi.md#payment_options_post) | **POST** /payment-options | Get payment options
[**quote_post**](DefaultApi.md#quote_post) | **POST** /quote | Get a quote or estimate
[**session_post**](DefaultApi.md#session_post) | **POST** /session | Start a session
[**verify_get**](DefaultApi.md#verify_get) | **GET** /verify | Provides token for authentication
[**withdrawal_post**](DefaultApi.md#withdrawal_post) | **POST** /withdrawal | Initiate a withdrawal

# **features_get**
> InlineResponse200 features_get()

Get supported features

Endpoint to retrieve supported features

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()

try:
    # Get supported features
    api_response = api_instance.features_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->features_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_post**
> InlineResponse2004 order_post(body)

Create an order

Confirm an order from quote and get payment information in return

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.OrderBody() # OrderBody | 

try:
    # Create an order
    api_response = api_instance.order_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->order_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrderBody**](OrderBody.md)|  | 

### Return type

[**InlineResponse2004**](InlineResponse2004.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **order_status_post**
> dict(str, InlineResponseMap200) order_status_post(body)

Get order status

This endpoint returns the status of one or more orders based on the session and order ID.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.OrderstatusBody() # OrderstatusBody | 

try:
    # Get order status
    api_response = api_instance.order_status_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->order_status_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**OrderstatusBody**](OrderstatusBody.md)|  | 

### Return type

[**dict(str, InlineResponseMap200)**](InlineResponseMap200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **payment_options_post**
> InlineResponse2006 payment_options_post(body)

Get payment options

This endpoint provides a list of payment options for different currencies, filtered by an optional currency code.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.PaymentoptionsBody() # PaymentoptionsBody | 

try:
    # Get payment options
    api_response = api_instance.payment_options_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->payment_options_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PaymentoptionsBody**](PaymentoptionsBody.md)|  | 

### Return type

[**InlineResponse2006**](InlineResponse2006.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quote_post**
> InlineResponse2003 quote_post(body)

Get a quote or estimate

Get a an quote or estimate from the provider based on amount of fiat you want to spend

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.QuoteBody() # QuoteBody | 

try:
    # Get a quote or estimate
    api_response = api_instance.quote_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->quote_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**QuoteBody**](QuoteBody.md)|  | 

### Return type

[**InlineResponse2003**](InlineResponse2003.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **session_post**
> InlineResponse2002 session_post(body)

Start a session

Start a session with optional signed proof of ownership. If Proof of Ownership is not required signature can be a random alphanumeric value.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.SessionBody() # SessionBody | 

try:
    # Start a session
    api_response = api_instance.session_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->session_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**SessionBody**](SessionBody.md)|  | 

### Return type

[**InlineResponse2002**](InlineResponse2002.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **verify_get**
> InlineResponse2001 verify_get()

Provides token for authentication

Request a token to be signed by the reciever node as proof of ownership

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()

try:
    # Provides token for authentication
    api_response = api_instance.verify_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->verify_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](InlineResponse2001.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **withdrawal_post**
> InlineResponse2005 withdrawal_post(body)

Initiate a withdrawal

Request lnurlw from the provider. User can provide optional fallback onchain address which will be used if the withdrawal is not claimed before the expiration date

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DefaultApi()
body = swagger_client.WithdrawalBody() # WithdrawalBody | 

try:
    # Initiate a withdrawal
    api_response = api_instance.withdrawal_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DefaultApi->withdrawal_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**WithdrawalBody**](WithdrawalBody.md)|  | 

### Return type

[**InlineResponse2005**](InlineResponse2005.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

