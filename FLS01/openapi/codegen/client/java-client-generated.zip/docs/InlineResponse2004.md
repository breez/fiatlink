# InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orderId** | [**UUID**](UUID.md) |  |  [optional]
**orderStatus** | **String** |  |  [optional]
**amountFiat** | **Integer** |  |  [optional]
**currencyId** | **Integer** |  |  [optional]
**paymentOptionId** | **Integer** |  |  [optional]
**amountSats** | **Integer** |  |  [optional]
**expiresOn** | [**OffsetDateTime**](OffsetDateTime.md) | by when the payment needs to arrive for the order to be honored |  [optional]
**paymentInfo** | **Map&lt;String, Object&gt;** |  |  [optional]
