# IO.Swagger.Model.InlineResponse2006
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Currencies** | **List&lt;Dictionary&lt;string, Object&gt;&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

