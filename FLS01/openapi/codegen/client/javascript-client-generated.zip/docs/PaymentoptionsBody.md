# FiatlinkFls01.PaymentoptionsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **String** |  | 
**currencyCode** | **String** |  | [optional] 
