'use strict';


/**
 * Get supported features
 * Endpoint to retrieve supported features
 *
 * returns inline_response_200
 **/
exports.featuresGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "supported_features" : [ {
    "on_chain_fallback" : false,
    "webhook" : true,
    "quotes" : true,
    "estimates" : true
  }, {
    "on_chain_fallback" : false,
    "webhook" : true,
    "quotes" : true,
    "estimates" : true
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Create an order
 * Confirm an order from quote and get payment information in return
 *
 * body Order_body 
 * returns inline_response_200_4
 **/
exports.orderPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "order_status" : "placed",
  "amount_fiat" : 100000,
  "amount_sats" : 800000,
  "expires_on" : "2023-09-20T00:25:11.123Z",
  "payment_info" : "",
  "order_id" : "8ed13c2a-a8c6-4f0e-b43e-3fdbf1f094a6",
  "payment_option_id" : 1,
  "currency_id" : 1
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get order status
 * This endpoint returns the status of one or more orders based on the session and order ID.
 *
 * body Orderstatus_body 
 * returns Map
 **/
exports.order_statusPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "key" : {
    "amount_fiat" : 100000,
    "order_status" : "finished",
    "btc_price" : 6942000,
    "amount_sats" : 800000,
    "order_fee" : 1234,
    "order_status_date" : "2023-09-20T00:25:11.123Z",
    "payment_option_id" : 1,
    "currency_id" : 1
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get payment options
 * This endpoint provides a list of payment options for different currencies, filtered by an optional currency code.
 *
 * body Paymentoptions_body 
 * returns inline_response_200_6
 **/
exports.payment_optionsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "currencies" : [ {
    "key" : {
      "currency_id" : 1,
      "currency_code" : "EUR",
      "payment_options" : [ {
        "min_amount" : 1000,
        "max_amount" : 100000,
        "id" : 1,
        "option" : "SEPA",
        "fee_rate" : 0.005
      }, {
        "min_amount" : 1000,
        "max_amount" : 100000,
        "id" : 1,
        "option" : "SEPA",
        "fee_rate" : 0.005
      } ]
    }
  }, {
    "key" : {
      "currency_id" : 1,
      "currency_code" : "EUR",
      "payment_options" : [ {
        "min_amount" : 1000,
        "max_amount" : 100000,
        "id" : 1,
        "option" : "SEPA",
        "fee_rate" : 0.005
      }, {
        "min_amount" : 1000,
        "max_amount" : 100000,
        "id" : 1,
        "option" : "SEPA",
        "fee_rate" : 0.005
      } ]
    }
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Get a quote or estimate
 * Get a an quote or estimate from the provider based on amount of fiat you want to spend
 *
 * body Quote_body 
 * returns inline_response_200_3
 **/
exports.quotePOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "amount_fiat" : 100000,
  "btc_price" : 6942000,
  "amount_sats" : 800000,
  "quote_id" : "8ed13c2a-a8c6-4f0e-b43e-3fdbf1f094a6",
  "expires_on" : "2023-09-20T00:25:11.123Z",
  "order_fee" : 1234,
  "payment_option_id" : 1,
  "is_estimate" : false,
  "currency_id" : 1
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Start a session
 * Start a session with optional signed proof of ownership. If Proof of Ownership is not required signature can be a random alphanumeric value.
 *
 * body Session_body 
 * returns inline_response_200_2
 **/
exports.sessionPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "expires_on" : "2023-09-20T00:25:11.123Z",
  "session_id" : "d7ef9a88-1ca1-4ac8-bc9e-da3d9824cdc5",
  "app_id" : "8ed13c2a-a8c6-4f0e-b43e-3fdbf1f094a6"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Provides token for authentication
 * Request a token to be signed by the reciever node as proof of ownership
 *
 * returns inline_response_200_1
 **/
exports.verifyGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "expires_on" : "2023-09-20T00:25:11.123Z",
  "session_id" : "d7ef9a88-1ca1-4ac8-bc9e-da3d9824cdc5",
  "token" : "yyq6qpj2a"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Initiate a withdrawal
 * Request lnurlw from the provider. User can provide optional fallback onchain address which will be used if the withdrawal is not claimed before the expiration date
 *
 * body Withdrawal_body 
 * returns inline_response_200_5
 **/
exports.withdrawalPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "withdrawal_expiration_date" : "2023-09-20T00:25:11.123Z",
  "lnurlw" : "LNURL...",
  "order_id" : "8ed13c2a-a8c6-4f0e-b43e-3fdbf1f094a6"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

