# PaymentoptionsBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**UUID**](UUID.md) |  | 
**currencyCode** | **String** |  |  [optional]
