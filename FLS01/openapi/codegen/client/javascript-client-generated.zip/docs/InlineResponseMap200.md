# FiatlinkFls01.InlineResponseMap200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountFiat** | **Number** |  | [optional] 
**currencyId** | **Number** |  | [optional] 
**paymentOptionId** | **Number** |  | [optional] 
**amountSats** | **Number** |  | [optional] 
**btcPrice** | **Number** |  | [optional] 
**orderFee** | **Number** |  | [optional] 
**orderStatus** | **String** |  | [optional] 
**orderStatusDate** | **Date** |  | [optional] 
