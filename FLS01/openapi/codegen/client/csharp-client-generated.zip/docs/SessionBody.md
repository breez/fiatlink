# IO.Swagger.Model.SessionBody
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SessionId** | **Guid?** |  | 
**AppId** | **Guid?** | serves as identifier of the application | [optional] 
**Signature** | **string** | token signed with the node&#x27;s private key, in zbase32 format | 
**NodePubkey** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

