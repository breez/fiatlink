# InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**QuoteId** | **string** |  | [optional] [default to null]
**AmountFiat** | **int32** |  | [default to null]
**CurrencyId** | **int32** |  | [default to null]
**PaymentOptionId** | **int32** |  | [default to null]
**AmountSats** | **int32** |  | [default to null]
**IsEstimate** | **bool** | return true if estimate or false if quote | [default to true]
**BtcPrice** | **int32** |  | [default to null]
**OrderFee** | **int32** |  | [default to null]
**ExpiresOn** | [**time.Time**](time.Time.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

