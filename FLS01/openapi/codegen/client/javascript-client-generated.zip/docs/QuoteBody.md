# FiatlinkFls01.QuoteBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
