# OrderBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | [**java.util.UUID**](java.util.UUID.md) |  | 
**quoteId** | [**java.util.UUID**](java.util.UUID.md) |  | 
**webhookUrl** | [**kotlin.String**](.md) | optional webhook for notifications |  [optional]
