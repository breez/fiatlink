# {{classname}}

All URIs are relative to *https://virtserver.swaggerhub.com/ALJAZ/fiatlink/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**FeaturesGet**](DefaultApi.md#FeaturesGet) | **Get** /features | Get supported features
[**OrderPost**](DefaultApi.md#OrderPost) | **Post** /order | Create an order
[**OrderStatusPost**](DefaultApi.md#OrderStatusPost) | **Post** /order-status | Get order status
[**PaymentOptionsPost**](DefaultApi.md#PaymentOptionsPost) | **Post** /payment-options | Get payment options
[**QuotePost**](DefaultApi.md#QuotePost) | **Post** /quote | Get a quote or estimate
[**SessionPost**](DefaultApi.md#SessionPost) | **Post** /session | Start a session
[**VerifyGet**](DefaultApi.md#VerifyGet) | **Get** /verify | Provides token for authentication
[**WithdrawalPost**](DefaultApi.md#WithdrawalPost) | **Post** /withdrawal | Initiate a withdrawal

# **FeaturesGet**
> InlineResponse200 FeaturesGet(ctx, )
Get supported features

Endpoint to retrieve supported features

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderPost**
> InlineResponse2004 OrderPost(ctx, body)
Create an order

Confirm an order from quote and get payment information in return

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**OrderBody**](OrderBody.md)|  | 

### Return type

[**InlineResponse2004**](inline_response_200_4.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **OrderStatusPost**
> map[string]InlineResponseMap200 OrderStatusPost(ctx, body)
Get order status

This endpoint returns the status of one or more orders based on the session and order ID.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**OrderstatusBody**](OrderstatusBody.md)|  | 

### Return type

[**map[string]InlineResponseMap200**](inline_response_map200.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **PaymentOptionsPost**
> InlineResponse2006 PaymentOptionsPost(ctx, body)
Get payment options

This endpoint provides a list of payment options for different currencies, filtered by an optional currency code.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**PaymentoptionsBody**](PaymentoptionsBody.md)|  | 

### Return type

[**InlineResponse2006**](inline_response_200_6.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **QuotePost**
> InlineResponse2003 QuotePost(ctx, body)
Get a quote or estimate

Get a an quote or estimate from the provider based on amount of fiat you want to spend

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**QuoteBody**](QuoteBody.md)|  | 

### Return type

[**InlineResponse2003**](inline_response_200_3.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SessionPost**
> InlineResponse2002 SessionPost(ctx, body)
Start a session

Start a session with optional signed proof of ownership. If Proof of Ownership is not required signature can be a random alphanumeric value.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**SessionBody**](SessionBody.md)|  | 

### Return type

[**InlineResponse2002**](inline_response_200_2.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **VerifyGet**
> InlineResponse2001 VerifyGet(ctx, )
Provides token for authentication

Request a token to be signed by the reciever node as proof of ownership

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**InlineResponse2001**](inline_response_200_1.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **WithdrawalPost**
> InlineResponse2005 WithdrawalPost(ctx, body)
Initiate a withdrawal

Request lnurlw from the provider. User can provide optional fallback onchain address which will be used if the withdrawal is not claimed before the expiration date

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**WithdrawalBody**](WithdrawalBody.md)|  | 

### Return type

[**InlineResponse2005**](inline_response_200_5.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

