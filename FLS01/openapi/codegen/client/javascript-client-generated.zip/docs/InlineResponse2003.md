# FiatlinkFls01.InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quoteId** | **String** |  | [optional] 
**amountFiat** | **Number** |  | 
**currencyId** | **Number** |  | 
**paymentOptionId** | **Number** |  | 
**amountSats** | **Number** |  | 
**isEstimate** | **Boolean** | return true if estimate or false if quote | [default to true]
**btcPrice** | **Number** |  | 
**orderFee** | **Number** |  | 
**expiresOn** | **Date** |  | [optional] 
