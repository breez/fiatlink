# InlineResponseMap200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountFiat** | **Integer** |  |  [optional]
**currencyId** | **Integer** |  |  [optional]
**paymentOptionId** | **Integer** |  |  [optional]
**amountSats** | **Integer** |  |  [optional]
**btcPrice** | **Integer** |  |  [optional]
**orderFee** | **Integer** |  |  [optional]
**orderStatus** | **String** |  |  [optional]
**orderStatusDate** | [**OffsetDateTime**](OffsetDateTime.md) |  |  [optional]
